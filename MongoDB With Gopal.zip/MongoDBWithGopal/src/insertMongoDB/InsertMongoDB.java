package insertMongoDB;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class InsertMongoDB {

	public static void main(String[] args) throws Exception {
		// ---------- Connecting DataBase -------------------------//
		MongoClient mongoClient = new MongoClient("localhost", 27017);

		// ---------- Creating DataBase ---------------------------//
		MongoDatabase db = mongoClient.getDatabase("gopal");

		// ---------- Creating Collection -------------------------//
		MongoCollection<Document> table = db.getCollection("employee");

		// ---------- Creating Document ---------------------------//
		Document doc = new Document("name", "gopal");
		doc.append("id", 111);
		// ----------- Inserting Data ------------------------------//
		table.insertOne(doc);
	}

}
