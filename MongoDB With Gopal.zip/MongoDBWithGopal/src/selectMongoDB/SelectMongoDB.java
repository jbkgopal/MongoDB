package selectMongoDB;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class SelectMongoDB {

	public static void main(String[] args) throws Exception {
		// ---------- Connecting DataBase -------------------------//
		MongoClient mongoClient = new MongoClient("localhost", 27017);

		// ---------- Creating DataBase ---------------------------//
		MongoDatabase db = mongoClient.getDatabase("gopal");

		// ---------- Creating Collection -------------------------//
		MongoCollection<Document> table = db.getCollection("employee");
		
		Document searchQuery = new Document();
		searchQuery.put("name", "gopal");
		FindIterable<Document> cursor = table.find(searchQuery);
		
		try (final MongoCursor<Document> cursorIterator = cursor.cursor()) {
		    while (cursorIterator.hasNext()) {
		        System.out.println(cursorIterator.next());
		    }
		}
	}

}
